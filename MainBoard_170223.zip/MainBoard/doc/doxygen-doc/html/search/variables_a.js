var searchData=
[
  ['velocityground',['velocityGround',['../structDJI_1_1onboardSDK_1_1RTKData.html#a002a95cd7df302a8622651b82fb5c173',1,'DJI::onboardSDK::RTKData::velocityGround()'],['../structDJI_1_1onboardSDK_1_1GPSData.html#ac33952b3d773936e44c478bd1e028ea9',1,'DJI::onboardSDK::GPSData::velocityGround()']]]
];

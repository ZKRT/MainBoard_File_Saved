#### Documentation can be found on the DJI Developer Website. Please refer to [Commandline Linux Documentation](https://developer.dji.com/onboard-sdk/documentation/github-platform-docs/commandline/README.html).

If you're new here, we recommend going through the [Getting Started Guide](https://developer.dji.com/onboard-sdk/documentation/quick-start/index.html).

*Note that this sample will no longer receive new funcitonality and will eventually be replaced by the new [Linux](../Linux/) sample.*
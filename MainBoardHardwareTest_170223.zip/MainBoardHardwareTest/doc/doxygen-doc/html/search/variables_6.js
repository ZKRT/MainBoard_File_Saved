var searchData=
[
  ['mag',['mag',['../structDJI_1_1onboardSDK_1_1BroadcastData.html#a1927a962764da10fd698fdf629126956',1,'DJI::onboardSDK::BroadcastData']]]
];
